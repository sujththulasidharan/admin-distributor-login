function showMessage() {
    alert("Hello! You clicked the button.");
}
